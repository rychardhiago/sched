<?php
include 'brasileirao.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>phplib football-data.org</title>
    <link href="./css/bootstrap.min.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div class="container">
    <div class="page-header">
        <h1>Showcasing some library functions...</h1>
    </div>
    <?php
    // Create instance of API class
    $api = new FootballData();
    echo "<p><hr><p>"; ?>
    <h3>Matches for the 2nd matchday of the Premiere League</h3>
    <table class="table table-striped">
        <tr>
            <th>HomeTeam</th>
            <th></th>
            <th>AwayTeam</th>
            <th colspan="3">Result</th>
        </tr>
        <?php foreach ($api->findMatchesByCompetitionAndMatchday('BSA', 27)->matches as $match) {  print_r($match); ?>
            <tr>
                <td><?php echo $match->homeTeam->name; ?></td>
                <td>-</td>
                <td><?php echo $match->awayTeam->name; ?></td>
                <td><?php echo $match->score->fullTime->homeTeam;  ?></td>
                <td>:</td>
                <td><?php echo $match->score->fullTime->awayTeam;  ?></td>
            </tr>
        <?php } ?>
    </table>

</div>
</body>
</html>